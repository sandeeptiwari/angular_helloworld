import { TxtformatterPipe } from './txtformatter.pipe';

describe('TxtformatterPipe', () => {
  it('create an instance', () => {
    const pipe = new TxtformatterPipe();
    expect(pipe).toBeTruthy();
  });
});
